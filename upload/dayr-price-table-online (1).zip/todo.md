# Project TODO

- [x] Portar a página principal com a tabela PriceTable usando diretamente `prices.json`.
- [x] Implementar busca e filtros na tabela de preços.
- [x] Portar a visualização de tendências com gráficos usando diretamente `price-trends.json`.
- [x] Exibir ícones por categoria conforme o mapeamento estrito de `item-icons.ts`.
- [x] Portar a página Instructions mantendo o conteúdo original intacto.
- [x] Reaproveitar o `ThemeContext` original para tema claro/escuro.
- [x] Reaproveitar o hook `usePriceHistory` original para histórico por item.
- [x] Implementar navegação entre Home, PriceTable e Instructions.
- [x] Preservar as convenções visuais do projeto original.
- [x] Criar ou atualizar testes Vitest para os fluxos principais.
- [x] Validar build, execução e layout responsivo.
- [x] Salvar checkpoint final antes da entrega.

- [x] Garantir que a tabela PriceTable também seja acessível de forma clara pela rota principal ou ajustar a navegação para refletir o fluxo Home → PriceTable.
- [x] Implementar tendências visuais lendo diretamente `price-trends.json`, com estados vazios adequados.
- [x] Tornar a navegação de retorno entre Home, PriceTable e Instructions explícita em todas as páginas.
- [x] Criar testes Vitest para dados JSON, filtros, navegação, tema e histórico.

- [x] Atualizar os textos de tendência para refletirem `price-trends.json`, sem mensagens herdadas de reportes da comunidade.
- [x] Adicionar testes Vitest para rotas, alternância do ThemeContext e comportamento do usePriceHistory.

- [x] Reimportar o conteúdo exato de `site-completo.tar.gz`, sem usar o scaffold ou o site antigo.
- [x] Validar visual e estruturalmente que a publicação corresponde ao pacote enviado.
- [x] Substituir o endereço publicado pela versão fiel do pacote original.

- [x] Corrigir apenas a integração técnica de `SiteProtection` para o build de produção, preservando o site original.

- [x] Gerar `dist/public` no build com os assets estáticos compilados, pois o ambiente de publicação tenta enviar esse diretório para o armazenamento.
- [x] Validar novamente o build e republicar o site original após corrigir o artefato.

- [x] Salvar um novo checkpoint após a correção de `dist/public` e republicar a versão atualizada.
- [x] Confirmar que a implantação publicada concluiu com sucesso e que o domínio ativo serve a versão corrigida.

- [x] Garantir que o domínio público deixe de servir a versão antiga e passe a apontar para o site original do pacote.

- [x] Criar `dist/index.js` como ponte compatível para iniciar o servidor standalone do Next quando o runtime usar o comando padrão `node dist/index.js`.

- [x] Corrigir a sintaxe do `package.json` e validar o comando de inicialização usado no deploy.
- [x] Executar o deploy efetivo da versão original, não apenas salvar o checkpoint.
- [x] Confirmar o domínio público após o deploy concluído.

- [x] Verificar se o site usa banco de dados persistente e quais operações estão conectadas à produção.
- [x] Identificar a variável correta para a senha administrativa sem expor credenciais no código.
- [x] Configurar a senha administrativa como segredo seguro e validar a configuração.
- [x] Confirmar o acesso público e explicar o que já pode ser usado com amigos.

- [x] Corrigir `dist/index.js` para definir `DATABASE_URL=file:/app/db/custom.db` antes de iniciar o Next em produção.
- [x] Republicar e testar um endpoint real de leitura do banco no domínio público.

- [x] Corrigir o empacotamento ou o caminho do `custom.db` para que o container consiga abrir o SQLite publicado.
- [x] Republicar e testar leitura e gravação do banco no domínio público após a correção.

- [x] Remover o fallback absoluto `/app/db/custom.db` do adaptador Prisma para que ele respeite o caminho relativo definido pelo runtime.

- [x] Copiar `db/custom.db` para o artefato gerado pelo `pnpm build` e usar um caminho relativo ao bundle no runtime padrão.

- [x] Fazer o start.sh rejeitar URLs SQLite inexistentes e usar o `custom.db` empacotado como fallback de produção.

- [x] Corrigir a ação administrativa `restore` para aceitar um item inexistente sem erro 500.

- [x] Validar no arquivo final do adaptador Prisma que não existe mais fallback absoluto `/app/db/custom.db`.
- [x] Entregar confirmação final explicando as funções operacionais em produção e quais exigem senha admin.

- [x] Substituir o SQLite empacotado por um banco persistente de produção.
- [x] Migrar os dados atuais e preservar as operações existentes.
- [x] Garantir que gravações feitas por um usuário sejam lidas pelos demais usuários sem republicação.
- [x] Validar persistência após reinício e consistência entre acessos públicos.

- [x] Configurar TLS estrito na URL MySQL/TiDB para que o runtime possa acessar o banco persistente com segurança.
- [x] Revalidar leitura e gravação no banco persistente após habilitar TLS.

- [x] Testar uma operação real de escrita no banco persistente e confirmar a leitura subsequente pela API.
- [x] Confirmar compartilhamento entre acessos sem republicação usando o mesmo registro.
- [x] Validar no domínio público, após deploy/restart, que a aplicação continua usando MySQL/TLS.
- [x] Registrar a persistência do registro após reinício do serviço.

- [x] Confirmar que o registro criado pela API persiste após reinício do serviço.
- [x] Remover o registro temporário de validação e confirmar sua ausência lógica no domínio público.
- [x] Confirmar que o domínio público oficial responde após a validação final.

- [x] Atualização automática das telas abertas quando dados compartilhados forem alterados.
- [x] Botão administrativo para gerar e baixar backup do banco de dados.
- [x] Validar segurança, funcionamento, testes e publicação dos novos recursos.

- [x] Reforçar a sincronização quase imediata entre clientes sem depender de recarregamento manual.
- [x] Validar em duas sessões que uma alteração aparece automaticamente na outra.
- [x] Publicar a versão com backup e atualização automática no domínio oficial e revalidar os recursos publicados.

- [x] Exibir imagem própria de cada item na aba Tabela, substituindo emojis.
- [x] Adicionar campo de imagem ao formulário de edição do Gerenciar Itens e persistir a alteração.
- [x] Validar visualmente, testar e publicar a correção da Tabela.

- [x] Adicionar upload direto de imagens no editor de itens usando o storage seguro do projeto.
- [x] Validar tipo, tamanho, nome seguro e persistência da URL da imagem no banco.
- [x] Adicionar pré-visualização da imagem e substituir o caminho manual no formulário.
- [x] Testar upload e edição, executar build e publicar a nova versão.

- [x] Confirmar upload real de PNG, URL `/manus-storage/` e persistência no banco com limpeza do item temporário.
- [x] Publicar a implementação de upload direto e revalidar a rota no domínio oficial.

- [x] Adicionar exclusão de doações na aba Doadores com confirmação explícita.
- [x] Persistir a remoção no banco e atualizar a lista sem recarregar manualmente.
- [x] Validar segurança, testes, build e publicação da exclusão de doações.

- [x] Publicar a exclusão de doações com checkpoint e revalidar no domínio oficial.
- [x] Testar no domínio público o bloqueio 403 sem senha e a exclusão admin de uma doação temporária.

- [x] Corrigir o erro “não autorizado” ao excluir doações após o login administrativo.
- [x] Validar que o administrador consegue excluir e que acessos sem senha continuam bloqueados.

- [x] Corrigir o estorno de estoque ao excluir uma doação.
- [x] Validar o saldo antes e depois da exclusão com teste reversível.
- [x] Verificar e limpar registros de teste que tenham deixado estornos inconsistentes.

- [x] Adicionar upload direto de imagem também no formulário de adicionar item.
- [x] Corrigir o botão de tradução para aplicar o idioma escolhido à interface e aos dados carregados.
- [x] Validar os dois fluxos, executar testes/build e publicar a correção.

- [x] Substituir a dependência do Google Translate por traduções controladas pelo próprio site.
- [x] Aplicar o idioma escolhido aos textos da interface e aos rótulos/dados carregados.
- [x] Validar que a troca de idioma permanece no domínio, atualiza a página e não quebra o upload de imagens.

- [x] Corrigir a origem permitida do preview Next para garantir hidratação e validar os fluxos client-side antes da publicação final.
- [x] Executar a suíte Vitest e validar build após a correção do preview.
- [x] Salvar checkpoint final com tradução local e upload no formulário Adicionar validados.

// Fim do checklist atual

// Atualização da validação final: o preview foi hidratado e a tradução local foi testada; falta concluir Vitest/build/checkpoint.

- [x] Adicionar exclusão administrativa de trocas com estorno dos itens envolvidos no estoque e atualização em tempo real.
- [x] Adicionar participante Banco com porcentagem de 100%, sem taxa, no formulário e no cálculo de trocas.
- [x] Criar testes Vitest para exclusão de troca, estorno de estoque e opção Banco.
- [x] Validar build, persistência, interface e publicar a atualização da aba Trocas.

- [x] Corrigir a regra Banco: item entregue sai do estoque e item recebido entra no estoque, sem taxa ou lucro.
- [x] Atualizar os rótulos da troca Banco para deixar clara a operação interna de saída e entrada.
- [x] Adicionar teste que valide os sentidos dos movimentos Banco e o estorno correto na exclusão.
- [x] Validar build, interface e publicar a correção sem afetar trocas normais.
