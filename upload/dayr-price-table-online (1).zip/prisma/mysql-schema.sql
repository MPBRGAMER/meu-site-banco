-- CreateTable
CREATE TABLE `Emprestimo` (
    `id` VARCHAR(191) NOT NULL,
    `player` VARCHAR(191) NOT NULL,
    `item` VARCHAR(191) NOT NULL,
    `quantidade` INTEGER NOT NULL,
    `dataEmprestimo` DATETIME(3) NOT NULL,
    `tipoMembro` VARCHAR(191) NOT NULL DEFAULT 'comum',
    `status` VARCHAR(191) NOT NULL DEFAULT 'pendente',
    `dataPagamento` DATETIME(3) NULL,
    `itemPagamento` VARCHAR(191) NULL,
    `quantidadePaga` INTEGER NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Investidor` (
    `id` VARCHAR(191) NOT NULL,
    `nome` VARCHAR(191) NOT NULL,
    `dataEntrada` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `status` VARCHAR(191) NOT NULL DEFAULT 'ativo',
    `observacao` VARCHAR(191) NULL,
    `ordem` INTEGER NOT NULL DEFAULT 0,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `TabelaTroca` (
    `id` VARCHAR(191) NOT NULL,
    `itemBase` VARCHAR(191) NOT NULL,
    `quantidadeBase` INTEGER NOT NULL,
    `itemResultado` VARCHAR(191) NOT NULL,
    `quantidadeResultado` INTEGER NOT NULL,
    `categoria` VARCHAR(191) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `TrocaRegistro` (
    `id` VARCHAR(191) NOT NULL,
    `player` VARCHAR(191) NOT NULL,
    `itemEnviado` VARCHAR(191) NOT NULL,
    `quantidadeEnviada` INTEGER NOT NULL,
    `itemRecebido` VARCHAR(191) NOT NULL,
    `quantidadeRecebida` INTEGER NOT NULL,
    `tipoMembro` VARCHAR(191) NOT NULL,
    `taxaAplicada` INTEGER NOT NULL,
    `lucroBanco` INTEGER NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `CompraVenda` (
    `id` VARCHAR(191) NOT NULL,
    `tipo` VARCHAR(191) NOT NULL,
    `player` VARCHAR(191) NOT NULL,
    `item` VARCHAR(191) NOT NULL,
    `quantidade` INTEGER NOT NULL,
    `itemPagamento` VARCHAR(191) NULL,
    `valor` DOUBLE NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `observacao` VARCHAR(191) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `CaixaRegistro` (
    `id` VARCHAR(191) NOT NULL,
    `tipo` VARCHAR(191) NOT NULL,
    `descricao` VARCHAR(191) NOT NULL,
    `item` VARCHAR(191) NOT NULL,
    `quantidade` INTEGER NOT NULL,
    `valor` DOUBLE NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `origem` VARCHAR(191) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Doador` (
    `id` VARCHAR(191) NOT NULL,
    `nome` VARCHAR(191) NOT NULL,
    `item` VARCHAR(191) NOT NULL,
    `quantidade` INTEGER NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `ordem` INTEGER NOT NULL DEFAULT 0,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Leilao` (
    `id` VARCHAR(191) NOT NULL,
    `donoItem` VARCHAR(191) NOT NULL,
    `nomeItem` VARCHAR(191) NOT NULL,
    `imagemUrl` VARCHAR(191) NULL,
    `quantidade` INTEGER NOT NULL DEFAULT 1,
    `valorInicial` DOUBLE NOT NULL,
    `moedaAceita` VARCHAR(191) NOT NULL,
    `taxaCasa` INTEGER NOT NULL DEFAULT 15,
    `status` VARCHAR(191) NOT NULL DEFAULT 'ativo',
    `dataCriacao` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `dataExpiracao` DATETIME(3) NOT NULL,
    `dataUltimoLance` DATETIME(3) NULL,
    `vencedor` VARCHAR(191) NULL,
    `valorVencedor` DOUBLE NULL,
    `tipoMembroVencedor` VARCHAR(191) NULL,
    `tipoOrigem` VARCHAR(191) NOT NULL DEFAULT 'comum',

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Lance` (
    `id` VARCHAR(191) NOT NULL,
    `leilaoId` VARCHAR(191) NOT NULL,
    `jogador` VARCHAR(191) NOT NULL,
    `valor` DOUBLE NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Sorteio` (
    `id` VARCHAR(191) NOT NULL,
    `nomeItem` VARCHAR(191) NOT NULL,
    `quantidade` INTEGER NOT NULL,
    `duracaoMinutos` INTEGER NOT NULL,
    `status` VARCHAR(191) NOT NULL DEFAULT 'ativo',
    `dataCriacao` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `dataFim` DATETIME(3) NULL,
    `ganhador` VARCHAR(191) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ParticipanteSorteio` (
    `id` VARCHAR(191) NOT NULL,
    `sorteioId` VARCHAR(191) NOT NULL,
    `jogador` VARCHAR(191) NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Loterica` (
    `id` VARCHAR(191) NOT NULL,
    `status` VARCHAR(191) NOT NULL DEFAULT 'vendas_abertas',
    `valorNumero` DOUBLE NOT NULL,
    `moedaAceita` VARCHAR(191) NOT NULL,
    `premioMinimo` DOUBLE NOT NULL DEFAULT 0,
    `premioAcumulado` DOUBLE NOT NULL DEFAULT 0,
    `duracaoMinutos` INTEGER NOT NULL DEFAULT 60,
    `dataCriacao` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `dataFimVendas` DATETIME(3) NULL,
    `dataSorteio` DATETIME(3) NULL,
    `numeroSorteado` INTEGER NULL,
    `ganhador` VARCHAR(191) NULL,
    `valorPremio` DOUBLE NOT NULL DEFAULT 0,
    `arrecadadoTotal` DOUBLE NOT NULL DEFAULT 0,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `NumeroLoterica` (
    `id` VARCHAR(191) NOT NULL,
    `lotericaId` VARCHAR(191) NOT NULL,
    `numero` INTEGER NOT NULL,
    `comprador` VARCHAR(191) NULL,
    `dataCompra` DATETIME(3) NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `PriceReport` (
    `id` VARCHAR(191) NOT NULL,
    `itemId` VARCHAR(191) NOT NULL,
    `itemName` VARCHAR(191) NOT NULL,
    `nickname` VARCHAR(191) NOT NULL,
    `steelQty` INTEGER NOT NULL,
    `steelPrice` INTEGER NOT NULL,
    `cementQty` INTEGER NOT NULL,
    `cementPrice` INTEGER NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ItemOverride` (
    `id` VARCHAR(191) NOT NULL,
    `itemId` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NULL,
    `categoryId` VARCHAR(191) NULL,
    `img` VARCHAR(191) NULL,
    `wikiLink` VARCHAR(191) NULL,
    `steel` VARCHAR(191) NULL,
    `cement` VARCHAR(191) NULL,
    `rarity` VARCHAR(191) NULL,
    `demand` VARCHAR(191) NULL,
    `notes` VARCHAR(191) NULL,
    `action` VARCHAR(191) NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `ItemOverride_itemId_key`(`itemId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ChatMensagem` (
    `id` VARCHAR(191) NOT NULL,
    `canal` VARCHAR(191) NOT NULL,
    `salaId` VARCHAR(191) NULL,
    `autor` VARCHAR(191) NOT NULL,
    `conteudo` VARCHAR(191) NOT NULL,
    `data` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `isAdmin` BOOLEAN NOT NULL DEFAULT false,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ChatSala` (
    `id` VARCHAR(191) NOT NULL,
    `nome` VARCHAR(191) NOT NULL,
    `criadoPor` VARCHAR(191) NOT NULL,
    `senha` VARCHAR(191) NULL,
    `dataCriacao` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Propaganda` (
    `id` VARCHAR(191) NOT NULL,
    `slotId` VARCHAR(191) NOT NULL,
    `codigo` VARCHAR(191) NOT NULL DEFAULT '',
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `Propaganda_slotId_key`(`slotId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Lance` ADD CONSTRAINT `Lance_leilaoId_fkey` FOREIGN KEY (`leilaoId`) REFERENCES `Leilao`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ParticipanteSorteio` ADD CONSTRAINT `ParticipanteSorteio_sorteioId_fkey` FOREIGN KEY (`sorteioId`) REFERENCES `Sorteio`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `NumeroLoterica` ADD CONSTRAINT `NumeroLoterica_lotericaId_fkey` FOREIGN KEY (`lotericaId`) REFERENCES `Loterica`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatMensagem` ADD CONSTRAINT `ChatMensagem_salaId_fkey` FOREIGN KEY (`salaId`) REFERENCES `ChatSala`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

