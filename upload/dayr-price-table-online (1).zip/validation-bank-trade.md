Validação visual do preview em 11/08/2026:

- A aplicação respondeu no domínio de preview do projeto.
- O fluxo administrativo abriu o modal de senha.
- O painel exibiu registros de estorno da troca BANCO no histórico do caixa.
- A correção final dos rótulos e da direção dos movimentos foi validada por Vitest e build; a publicação final ainda depende do checkpoint desta alteração.
