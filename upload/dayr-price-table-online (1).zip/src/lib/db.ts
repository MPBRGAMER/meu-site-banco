import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

const rawDatabaseUrl = process.env.DATABASE_URL;
const databaseUrl = rawDatabaseUrl && !rawDatabaseUrl.startsWith("file:")
  ? rawDatabaseUrl.includes("sslaccept=")
    ? rawDatabaseUrl
    : `${rawDatabaseUrl}${rawDatabaseUrl.includes("?") ? "&" : "?"}sslaccept=strict`
  : rawDatabaseUrl || "file:./db/custom.db";

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: databaseUrl,
    log: ['query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db