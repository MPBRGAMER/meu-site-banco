import crypto from "node:crypto";

function getForgeConfig() {
  const forgeUrl = process.env.BUILT_IN_FORGE_API_URL;
  const forgeKey = process.env.BUILT_IN_FORGE_API_KEY;
  if (!forgeUrl || !forgeKey) {
    throw new Error("Storage config missing: BUILT_IN_FORGE_API_URL/BUILT_IN_FORGE_API_KEY");
  }
  return { forgeUrl: forgeUrl.replace(/\/+$/, ""), forgeKey };
}

function normalizeKey(relKey: string) {
  return relKey.replace(/^\/+/, "");
}

function appendHashSuffix(relKey: string) {
  const hash = crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  const dot = relKey.lastIndexOf(".");
  return dot === -1 ? `${relKey}_${hash}` : `${relKey.slice(0, dot)}_${hash}${relKey.slice(dot)}`;
}

export async function storagePut(
  relKey: string,
  data: Buffer | Uint8Array,
  contentType: string,
): Promise<{ key: string; url: string }> {
  const { forgeUrl, forgeKey } = getForgeConfig();
  const key = appendHashSuffix(normalizeKey(relKey));
  const presignUrl = new URL("v1/storage/presign/put", `${forgeUrl}/`);
  presignUrl.searchParams.set("path", key);
  const presign = await fetch(presignUrl, { headers: { Authorization: `Bearer ${forgeKey}` } });
  if (!presign.ok) throw new Error(`Storage presign failed (${presign.status})`);
  const { url } = (await presign.json()) as { url?: string };
  if (!url) throw new Error("Storage returned an empty upload URL");
  const upload = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": contentType },
    body: data as BodyInit,
  });
  if (!upload.ok) throw new Error(`Storage upload failed (${upload.status})`);
  return { key, url: `/manus-storage/${key}` };
}
