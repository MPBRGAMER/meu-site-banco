# Validação da correção de imagens

- O catálogo contém 332 itens e 332 campos `img`; não há itens sem caminho de imagem.
- O asset `/items/canned_water.png` foi aberto diretamente no preview e carregou corretamente.
- A tabela agora deriva `/items/{id}.png` quando necessário e não usa mais emoji como fallback; falhas exibem um marcador neutro de imagem indisponível.
- O formulário de edição tem campo de imagem e a rota `/api/items` salva `img` em alterações.
- `pnpm run build` foi executado com sucesso.
- Vitest passou com 3 testes, incluindo criação temporária, edição do caminho de imagem e limpeza do registro.
- A validação visual da página completa ficou limitada porque o preview permaneceu em carregamento dos dados do banco; o asset visual isolado foi confirmado diretamente.
