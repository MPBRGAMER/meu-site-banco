import { describe, expect, it } from "vitest";

describe("admin password configuration", () => {
  it("accepts the configured ADMIN_PASSWORD through the public verification endpoint", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";

    expect(password).toBeTruthy();

    const response = await fetch(
      `${baseUrl}/api/banco?action=verifyAdmin&password=${encodeURIComponent(password || "")}`,
    );

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ success: true });
  });
});
