import { describe, expect, it } from "vitest";
import { db } from "../src/lib/db";

describe("admin password configuration", () => {
  it("accepts the configured ADMIN_PASSWORD through the public verification endpoint", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";

    expect(password).toBeTruthy();

    const response = await fetch(
      `${baseUrl}/api/banco?action=verifyAdmin&password=${encodeURIComponent(password || "")}`,
    );

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ success: true });
  });
});

describe("admin database backup", () => {
  it("returns a downloadable JSON backup only with the admin password", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";

    expect(password).toBeTruthy();

    const unauthorized = await fetch(`${baseUrl}/api/banco`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "backup" }),
    });
    expect(unauthorized.status).toBe(403);

    const response = await fetch(`${baseUrl}/api/banco`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-admin-password": password || "",
      },
      body: JSON.stringify({ action: "backup" }),
    });

    expect(response.status).toBe(200);
    expect(response.headers.get("content-disposition")).toContain("attachment");
    const payload = await response.json();
    expect(payload.format).toBe("dayr-banco-backup-v1");
    expect(payload.data).toHaveProperty("emprestimos");
    expect(payload.data).toHaveProperty("caixa");
  });
});

describe("item image editing", () => {
  it("persists an edited image path and cleans up the temporary item", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";
    const itemId = `__teste_imagem_${Date.now()}`;
    const headers = {
      "Content-Type": "application/json",
      "x-admin-password": password || "",
    };

    expect(password).toBeTruthy();
    try {
      const added = await fetch(`${baseUrl}/api/items`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          action: "add",
          item: {
            itemId,
            name: "Item temporário de imagem",
            categoryId: "resources",
            img: "/items/canned_water.png",
            steel: "?:?",
            cement: "?:?",
            rarity: "common",
            demand: "medium",
            notes: "",
          },
        }),
      });
      expect(added.status).toBe(200);

      const edited = await fetch(`${baseUrl}/api/items`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          action: "edit",
          item: { itemId, img: "/items/coffee.png" },
        }),
      });
      expect(edited.status).toBe(200);
      await expect(edited.json()).resolves.toMatchObject({ itemId, img: "/items/coffee.png" });
    } finally {
      await fetch(`${baseUrl}/api/items`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "restore", item: { itemId } }),
      });
    }
  });
});

describe("item image upload validation", () => {
  it("protects the upload endpoint and rejects non-image files", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";
    expect(password).toBeTruthy();

    const unauthorizedForm = new FormData();
    unauthorizedForm.append("itemId", "teste");
    unauthorizedForm.append("image", new Blob(["not-an-image"], { type: "text/plain" }), "file.txt");
    const unauthorized = await fetch(`${baseUrl}/api/items`, { method: "POST", body: unauthorizedForm });
    expect(unauthorized.status).toBe(403);

    const invalidForm = new FormData();
    invalidForm.append("itemId", "teste");
    invalidForm.append("image", new Blob(["not-an-image"], { type: "text/plain" }), "file.txt");
    const invalid = await fetch(`${baseUrl}/api/items`, {
      method: "POST",
      headers: { "x-admin-password": password || "" },
      body: invalidForm,
    });
    expect(invalid.status).toBe(400);
    await expect(invalid.json()).resolves.toMatchObject({ error: expect.stringContaining("Formato") });
  });
});

describe("item image upload persistence", () => {
  it("uploads a valid PNG and persists the returned storage URL on the item", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";
    const itemId = `__teste_upload_${Date.now()}`;
    const headers = { "x-admin-password": password || "" };
    const pngBytes = Uint8Array.from(Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=", "base64"));
    expect(password).toBeTruthy();

    try {
      const form = new FormData();
      form.append("itemId", itemId);
      form.append("image", new Blob([pngBytes], { type: "image/png" }), "pixel.png");
      const upload = await fetch(`${baseUrl}/api/items`, { method: "POST", headers, body: form });
      expect(upload.status).toBe(200);
      const uploaded = await upload.json();
      expect(uploaded.url).toMatch(/^\/manus-storage\//);

      const added = await fetch(`${baseUrl}/api/items`, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "add",
          item: { itemId, name: "Item temporário upload", categoryId: "resources", img: uploaded.url, steel: "?:?", cement: "?:?", rarity: "common", demand: "medium", notes: "" },
        }),
      });
      expect(added.status).toBe(200);
      await expect(added.json()).resolves.toMatchObject({ itemId, img: uploaded.url });
    } finally {
      await fetch(`${baseUrl}/api/items`, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({ action: "restore", item: { itemId } }),
      });
    }
  });
});

describe("donation deletion", () => {
  it("removes a donation and records a reversible stock reversal", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";
    const name = `__teste_doacao_${Date.now()}`;
    const headers = { "Content-Type": "application/json", "x-admin-password": password || "" };
    expect(password).toBeTruthy();
    const unauthorized = await fetch(`${baseUrl}/api/banco`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "removeDoador", id: "__nao_autorizado__" }),
    });
    expect(unauthorized.status).toBe(403);

    let doadorId = "";
    let reversalOrigin = "";
    try {
      const added = await fetch(`${baseUrl}/api/banco`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "addDoador", nome: name, item: "__item_teste", quantidade: 7 }),
      });
      expect(added.status).toBe(200);
      const created = await added.json();
      doadorId = created.id;
      reversalOrigin = `estorno-doacao:${doadorId}`;

      const addedStock = await fetch(`${baseUrl}/api/banco`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "addCaixa", tipo: "entrada", descricao: `Doação de ${name}`, item: "__item_teste", quantidade: 7, origem: `doacao:${doadorId}` }),
      });
      expect(addedStock.status).toBe(200);

      const removed = await fetch(`${baseUrl}/api/banco`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "removeDoador", id: doadorId }),
      });
      expect(removed.status).toBe(200);
      await expect(removed.json()).resolves.toMatchObject({ stockReversed: true });

      const listed = await fetch(`${baseUrl}/api/banco?action=listDoadores`);
      const donors = await listed.json();
      expect(donors.some((d: { id: string }) => d.id === doadorId)).toBe(false);
      await expect(db.caixaRegistro.findFirst({ where: { origem: reversalOrigin } })).resolves.toMatchObject({ tipo: "saida", quantidade: 7 });
    } finally {
      if (reversalOrigin) await db.caixaRegistro.deleteMany({ where: { origem: reversalOrigin } });
      if (doadorId) await db.caixaRegistro.deleteMany({ where: { origem: `doacao:${doadorId}` } });
      if (doadorId) await db.doador.deleteMany({ where: { id: doadorId } });
    }
  });
});

describe("trade deletion and stock reversal", () => {
  it("removes a trade only for admin and reverses its stock entry", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";
    const player = `__teste_troca_${Date.now()}`;
    const headers = { "Content-Type": "application/json", "x-admin-password": password || "" };
    expect(password).toBeTruthy();

    const unauthorized = await fetch(`${baseUrl}/api/banco`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "removeTroca", id: "__nao_autorizada__" }),
    });
    expect(unauthorized.status).toBe(403);

    let trocaId = "";
    try {
      const added = await fetch(`${baseUrl}/api/banco`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "addTroca", player, itemEnviado: "__item_entrada__", quantidadeEnviada: 3, itemRecebido: "__item_taxa__", quantidadeRecebida: 8, tipoMembro: "comum", taxaAplicada: 15, lucroBanco: 2 }),
      });
      expect(added.status).toBe(200);
      const created = await added.json();
      trocaId = created.id;

      const removed = await fetch(`${baseUrl}/api/banco`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "removeTroca", id: trocaId }),
      });
      expect(removed.status).toBe(200);
      await expect(removed.json()).resolves.toMatchObject({ stockReversed: true, reversedMovements: 3 });
      await expect(db.trocaRegistro.findUnique({ where: { id: trocaId } })).resolves.toBeNull();
      const reversals = await db.caixaRegistro.findMany({ where: { origem: { startsWith: `estorno-troca:${trocaId}:` } } });
      expect(reversals).toHaveLength(3);
      expect(reversals).toEqual(expect.arrayContaining([
        expect.objectContaining({ tipo: "saida", item: "__item_entrada__", quantidade: 3 }),
        expect.objectContaining({ tipo: "entrada", item: "__item_taxa__", quantidade: 8 }),
        expect.objectContaining({ tipo: "saida", item: "__item_taxa__", quantidade: 2 }),
      ]));
    } finally {
      if (trocaId) {
        await db.caixaRegistro.deleteMany({ where: { OR: [{ origem: { startsWith: `troca:${trocaId}:` } }, { origem: { startsWith: `estorno-troca:${trocaId}:` } }] } });
        await db.trocaRegistro.deleteMany({ where: { id: trocaId } });
      }
    }
  });
});

describe("bank trade type", () => {
  it("persists Banco as 100% with zero fee and no fee stock entry", async () => {
    const password = process.env.ADMIN_PASSWORD;
    const baseUrl = process.env.TEST_BASE_URL || "http://localhost:3000";
    const player = `__teste_banco_${Date.now()}`;
    const headers = { "Content-Type": "application/json", "x-admin-password": password || "" };
    expect(password).toBeTruthy();

    let trocaId = "";
    try {
      const added = await fetch(`${baseUrl}/api/banco`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "addTroca", player, itemEnviado: "__item_banco_entrada__", quantidadeEnviada: 5, itemRecebido: "__item_banco_saida__", quantidadeRecebida: 10, tipoMembro: "banco", taxaAplicada: 0, lucroBanco: 0 }),
      });
      expect(added.status).toBe(200);
      const created = await added.json();
      trocaId = created.id;
      expect(created).toMatchObject({ tipoMembro: "banco", taxaAplicada: 0, lucroBanco: 0 });
      const movements = await db.caixaRegistro.findMany({ where: { origem: { startsWith: `troca:${trocaId}:` } } });
      expect(movements).toHaveLength(2);
      expect(movements).toEqual(expect.arrayContaining([
        expect.objectContaining({ tipo: "saida", item: "__item_banco_entrada__", quantidade: 5 }),
        expect.objectContaining({ tipo: "entrada", item: "__item_banco_saida__", quantidade: 10 }),
      ]));
      expect(movements.some((m) => m.origem.endsWith(":taxa"))).toBe(false);

      const removed = await fetch(`${baseUrl}/api/banco`, {
        method: "POST",
        headers,
        body: JSON.stringify({ action: "removeTroca", id: trocaId }),
      });
      expect(removed.status).toBe(200);
      await expect(removed.json()).resolves.toMatchObject({ stockReversed: true, reversedMovements: 2 });
      const reversals = await db.caixaRegistro.findMany({ where: { origem: { startsWith: `estorno-troca:${trocaId}:` } } });
      expect(reversals).toEqual(expect.arrayContaining([
        expect.objectContaining({ tipo: "entrada", item: "__item_banco_entrada__", quantidade: 5 }),
        expect.objectContaining({ tipo: "saida", item: "__item_banco_saida__", quantidade: 10 }),
      ]));
    } finally {
      if (trocaId) {
        await db.caixaRegistro.deleteMany({ where: { OR: [{ origem: { startsWith: `troca:${trocaId}:` } }, { origem: { startsWith: `estorno-troca:${trocaId}:` } }] } });
        await db.trocaRegistro.deleteMany({ where: { id: trocaId } });
      }
    }
  });
});
