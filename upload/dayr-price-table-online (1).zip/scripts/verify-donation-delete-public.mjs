const baseUrl = process.env.TEST_BASE_URL || "https://dayrtable-cj3mjtv4.manus.space";
const password = process.env.ADMIN_PASSWORD;
if (!password) throw new Error("ADMIN_PASSWORD é obrigatório");

const jsonHeaders = { "Content-Type": "application/json" };
const adminHeaders = { ...jsonHeaders, "x-admin-password": password };
const name = `__teste_publico_doacao_${Date.now()}`;
let doadorId = "";

async function post(body, headers = jsonHeaders) {
  return fetch(`${baseUrl}/api/banco`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });
}

try {
  const added = await post({ action: "addDoador", nome: name, item: "__item_publico_teste", quantidade: 3 });
  if (added.status !== 200) throw new Error(`addDoador retornou ${added.status}: ${await added.text()}`);
  const created = await added.json();
  doadorId = created.id;

  const unauthorized = await post({ action: "removeDoador", id: doadorId });
  if (unauthorized.status !== 403) throw new Error(`remoção sem senha retornou ${unauthorized.status}: ${await unauthorized.text()}`);

  const removed = await post({ action: "removeDoador", id: doadorId }, adminHeaders);
  if (removed.status !== 200) throw new Error(`remoção admin retornou ${removed.status}: ${await removed.text()}`);

  const listed = await fetch(`${baseUrl}/api/banco?action=listDoadores`);
  if (listed.status !== 200) throw new Error(`listDoadores retornou ${listed.status}`);
  const donors = await listed.json();
  if (donors.some((d) => d.id === doadorId)) throw new Error("a doação excluída ainda aparece na lista");

  console.log(JSON.stringify({ success: true, unauthorizedStatus: unauthorized.status, removedStatus: removed.status, removedId: doadorId }));
} finally {
  if (doadorId) {
    await post({ action: "removeDoador", id: doadorId }, adminHeaders).catch(() => {});
  }
}
