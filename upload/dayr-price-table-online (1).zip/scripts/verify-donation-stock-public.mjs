const baseUrl = process.env.BASE_URL || "https://dayrtable-cj3mjtv4.manus.space";
const password = process.env.ADMIN_PASSWORD;
if (!password) throw new Error("ADMIN_PASSWORD ausente");
const headers = { "content-type": "application/json", "x-admin-password": password };
const item = "__item_publico_stock_fix";
const name = `__teste_stock_fix_${Date.now()}`;
const post = async (body, customHeaders = headers) => {
  const response = await fetch(`${baseUrl}/api/banco`, { method: "POST", headers: customHeaders, body: JSON.stringify(body) });
  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  if (!response.ok) throw new Error(`${body.action} ${response.status}: ${JSON.stringify(data)}`);
  return data;
};
const listCaixa = async () => {
  const response = await fetch(`${baseUrl}/api/banco?action=listCaixa&verify=${Date.now()}`);
  if (!response.ok) throw new Error(`listCaixa ${response.status}`);
  return response.json();
};
const created = await post({ action: "addDoador", nome: name, item, quantidade: 7 });
const donorId = created.id;
const entrada = await post({ action: "addCaixa", tipo: "entrada", descricao: `Doação de ${name}`, item, quantidade: 7, origem: `doacao:${donorId}` });
const before = await listCaixa();
const beforeNet = before.filter((row) => row.item === item).reduce((sum, row) => sum + (row.tipo === "entrada" ? Number(row.quantidade) : -Number(row.quantidade)), 0);
const removed = await post({ action: "removeDoador", id: donorId });
const after = await listCaixa();
const afterNet = after.filter((row) => row.item === item).reduce((sum, row) => sum + (row.tipo === "entrada" ? Number(row.quantidade) : -Number(row.quantidade)), 0);
if (!removed.stockReversed || beforeNet !== 7 || afterNet !== 0) throw new Error(`Saldo inconsistente: ${JSON.stringify({ beforeNet, afterNet, removed })}`);
console.log(JSON.stringify({ success: true, donorId, entradaId: entrada.id, reversal: removed.stockReversed, beforeNet, afterNet, item }));
