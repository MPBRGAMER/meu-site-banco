import fs from "node:fs";
const prices = JSON.parse(fs.readFileSync("src/data/prices.json", "utf8"));
const items = prices.categories.flatMap((category) => category.items);
const missing = items.filter((item) => !item.img).map((item) => ({ id: item.id, name: item.name }));
console.log(JSON.stringify({ total: items.length, missing }, null, 2));
