const baseUrl = process.env.VERIFY_BASE_URL || "https://dayrtable-cj3mjtv4.manus.space";
const password = process.env.ADMIN_PASSWORD;
if (!password) throw new Error("ADMIN_PASSWORD ausente no ambiente de validação");
const itemId = `__teste_upload_publico_${Date.now()}`;
const png = Uint8Array.from(Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=", "base64"));
const adminHeaders = { "x-admin-password": password };

const unauthorized = await fetch(`${baseUrl}/api/items`, { method: "POST" });
if (unauthorized.status !== 403) throw new Error(`unauthorized status ${unauthorized.status}`);

let uploaded;
try {
  const form = new FormData();
  form.append("itemId", itemId);
  form.append("image", new Blob([png], { type: "image/png" }), "pixel.png");
  const upload = await fetch(`${baseUrl}/api/items`, { method: "POST", headers: adminHeaders, body: form });
  const uploadBody = await upload.json();
  if (upload.status !== 200 || !/^\/manus-storage\//.test(uploadBody.url || "")) {
    throw new Error(`upload failed ${upload.status}: ${JSON.stringify(uploadBody)}`);
  }
  uploaded = uploadBody;

  const added = await fetch(`${baseUrl}/api/items`, {
    method: "POST",
    headers: { ...adminHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({ action: "add", item: { itemId, name: "Item temporário upload público", categoryId: "resources", img: uploaded.url, steel: "?:?", cement: "?:?", rarity: "common", demand: "medium", notes: "" } }),
  });
  const addedBody = await added.json();
  if (added.status !== 200 || addedBody.img !== uploaded.url) throw new Error(`persist failed ${added.status}`);
  console.log(JSON.stringify({ unauthorized: unauthorized.status, upload: upload.status, persisted: added.status, urlPrefix: uploaded.url.split("/").slice(0, 3).join("/") }));
} finally {
  await fetch(`${baseUrl}/api/items`, {
    method: "POST",
    headers: { ...adminHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({ action: "restore", item: { itemId } }),
  });
}
